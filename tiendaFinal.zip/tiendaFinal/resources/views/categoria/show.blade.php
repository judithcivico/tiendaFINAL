<!-- resources/views/catalog/show.blade.php -->
<style>
    table {
        border-collapse: collapse;
        width: 800px;
    }

    table, th, td {
        border: 1px solid black;
    }

    th, td {
        padding: 5px;
        text-align: left;
    }
</style>
<h2>Categorías</h2>
<table>
    <thead>
        <tr>
            <th>Nombre</th>
            <th>Descripción</th>
            <th>Fecha</th>
        </tr>
    </thead>
    <tbody>
        @foreach($categorias as $categoria)
        <tr>
            <td>{{ $categoria->nombre }}</td>
            <td>{{ $categoria->descripcion }}</td>
            <td>{{ $categoria->created_at }}</td>
        </tr>
        @endforeach
    </tbody>
</table><br><br>

<a href="{{ route('menuUser.pagPrincipal') }}"><button>Volver</button></a>
