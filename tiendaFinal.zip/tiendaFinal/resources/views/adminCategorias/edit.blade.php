<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <h2>Categorias</h2>
                <div class="card-body">
                    <form method="POST" action="{{ url('adminCategorias/'.$categoria->id) }}">
                        @method("PUT")
                        @csrf
                        <br>
                        <div class="form-group">
                            <label for="nombre">Nombre</label>
                            <input type="text" name="nombre" id="nombre" class="form-control" value="{{$categoria->nombre}}" required>
                        </div><br>

                        <div class="form-group">
                            <label for="descripcion">Descripción</label>
                            <input type="text" name="descripcion" id="descripcion" class="form-control" value="{{$categoria->descripcion}}">
                        </div><br>

                        <button type="submit" class="btn btn-primary">Editar Categoria</button>

                        <a href="{{ url('pokemon') }}">Volver</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
