<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <h2>Categorias</h2>
                <div class="card-body">
                    <form method="POST" action="{{ route('adminCategorias.store') }}">
                        @csrf
                        <br>
                        <div class="form-group">
                            <label for="nombre">Nombre</label>
                            <input type="text" name="nombre" id="nombre" class="form-control" required>
                        </div><br>

                        <div class="form-group">
                            <label for="descripcion">Descripción</label>
                            <input type="text" name="descripcion" id="descripcion" class="form-control" required>
                        </div><br>

                        <button type="submit" class="btn btn-primary">Crear Categoria</button><br><br>

                        <a href="{{ route('adminCategorias.index') }}">Volver</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>