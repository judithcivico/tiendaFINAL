<style>
    table {
        border-collapse: collapse;
        width: 800px;
    }

    table, th, td {
        border: 1px solid black;
    }

    th, td {
        padding: 5px;
        text-align: left;
    }
</style>
<main>
    <div class="container">
        <h2>Administrar productos</h2>

        <a href="{{url('adminCategorias/create')}}">Nuevo producto</a><br><br>

        <table class="table table-hover border">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Descripción</th>
                </tr>
            </thead>
            
            <tbody>
                @foreach ($categorias as $categoria)
                    <tr>
                        <td>{{$categoria->id}}</td>
                        <td>{{$categoria->nombre}}</td>
                        <td>{{$categoria->descripcion}}</td>
                        <td><a href="{{ route('adminCategorias.edit', ['id' => $categoria->id]) }}"><button>Editar</button></a></td>
                        <td><form action="{{url('adminCategorias/'.$categoria->id)}}" method="POST">
                                @method("DELETE")
                                @csrf
                                <button type="submit">Eliminar</button>
                            </form>
                        </td>     
                    </tr>
                @endforeach
            </tbody>
        </table><br><br>
        <a href="{{ route('menuAdmin.index') }}"><button>Volver</button></a>
    </div>
</main>
