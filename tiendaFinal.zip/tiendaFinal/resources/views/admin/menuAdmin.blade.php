<body>
    <h1>Hola Admin</h1>
    <a href="{{ url('/adminProductos') }}"><button>Administrar productos</button></a>
    <a href="{{ url('/adminCategorias') }}"><button>Administrar categorias</button></a>
    <a href="{{ url('/adminUsers') }}"><button>Administrar usuarios</button></a><br><br>

    @auth
        <form id="logout-form" method="POST" action="{{ route('logout') }}">
            @csrf
            <button type="button" onclick="confirmLogout()">Logout</button>
        </form>

        <script>
            function confirmLogout() {
                if (confirm('¿Estás seguro de que deseas cerrar sesión?')) {
                    document.getElementById('logout-form').submit();
                }
            }
        </script>
    @endauth
</body>
