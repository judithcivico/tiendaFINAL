<style>
    table {
        border-collapse: collapse;
        width: 1000px;
    }

    table, th, td {
        border: 1px solid black;
    }

    th, td {
        padding: 5px;
        text-align: left;
    }
</style>

<main>
    <div class="container">
        <h2>Administrar usuarios</h2>

        <a href="{{ route('adminUsers.create') }}">Nuevo usuario</a><br><br>

        <table class="table table-hover border">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nick</th>
                    <th>Nombre</th>
                    <th>Apellido</th>
                    <th>Correo</th>
                    <th>Role</th>
                    <th>DNI</th>
                    <th>Fecha nacimiento</th>
                </tr>
            </thead>

            <tbody>
                @foreach ($users as $user)
                    <tr>
                        <td>{{ $user->id }}</td>
                        <td>{{ $user->nick}}</td>
                        <td>{{ $user->nombre }}</td>
                        <td>{{ $user->apellido }}</td>
                        <td>{{ $user->email }}</td>
                        <td>{{ $user->role }}</td>
                        <td>{{ $user->dni }}</td>
                        <td>{{ $user->fecha_nacimiento }}</td>
                        <td><a href="{{ route('adminUsers.edit', ['id' => $user->id]) }}"><button>Editar</button></a></td>
                        <td><form action="{{url('adminUsers/'.$user->id)}}" method="POST">
                                @method("DELETE")
                                @csrf
                                <button type="submit">Eliminar</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table><br><br>
        
        <a href="{{ route('menuAdmin.index') }}"><button>Volver</button></a>
    </div>
</main>
