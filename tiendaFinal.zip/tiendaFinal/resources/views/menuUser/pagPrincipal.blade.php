<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Hola Usuario</h1>
    <a href="{{ url('/menuUser') }}"><button>Perfil de usuario</button></a>
    <a href="{{ url('/catalog') }}"><button>Catalogo de productos</button></a>
    <a href="{{ url('/categorias') }}"><button>Categorias</button></a>
    <a href="{{ url('/cart') }}"><button>Carrito</button></a><br><br>
</body>

@auth
    <form id="logout-form" method="POST" action="{{ route('logout') }}">
        @csrf
        <button type="button" onclick="confirmLogout()">Logout</button>
    </form>

    <script>
        function confirmLogout() {
            if (confirm('¿Estás seguro de que deseas cerrar sesión?')) {
                document.getElementById('logout-form').submit();
            }
        }
    </script>
@endauth
</html>