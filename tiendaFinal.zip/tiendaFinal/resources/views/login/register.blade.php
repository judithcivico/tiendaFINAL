<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro</title>
</head>
<body>
    <h1>Registro</h1>
    <form method="POST" action="{{ route('usuarios.store') }}">
        @csrf        
        <label for="nick">Nick:</label>
        <input type="text" id="nick" name="nick" required><br><br>

        <label for="email">Correo Electrónico:</label>
        <input type="email" id="email" name="email" required><br><br>

        <label for="nombre">Nombre:</label>
        <input type="text" id="nombre" name="nombre" required><br><br>

        <label for="apellido">Apellidos:</label>
        <input type="text" id="apellido" name="apellido" required><br><br>

        <label for="dni">DNI:</label>
        <input type="text" id="dni" name="dni" required><br><br>

        <label for="fecha_nacimiento">Fecha Nacimiento:</label>
        <input type="date" id="fecha_nacimiento" name="fecha_nacimiento" required><br><br>

        <label for="password">Contraseña:</label>
        <input type="password" id="password" name="password" required><br><br>

        <label for="role">Rol:</label>
        <select id="role" name="role" required>
            <option value="usuario">usuario</option>
            <option value="administrador">administrador</option>
        </select>
        <br><br>

        <button type="submit">Registrarse</button><br><br>

        <a href="{{ route('login.index') }}">Volver</a>   
    </form>
</body>
</html>