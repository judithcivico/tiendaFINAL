<!-- resources/views/catalog/show.blade.php -->
<style>
    table {
        border-collapse: collapse;
        width: 800px;
    }

    table, th, td {
        border: 1px solid black;
    }

    th, td {
        padding: 5px;
        text-align: left;
    }
</style>
<h1>Catálogo de Productos</h1>

<form action="{{ url('/catalog') }}" method="get" id="filterForm">
    @csrf
    <label for="category">Buscar por categoría:</label>
    <select name="category" id="category" >
        <option value="" { $categoryFilter = '' }>Mostrar Todos</option>
        <option value="Categoria A" { $categoryFilter = 'Categoria A' }>Categoria A</option>
        <option value="Categoria B" { $categoryFilter = 'Categoria B' }>Categoria B</option>
        <option value="Categoria C" { $categoryFilter ='Categoria C' }>Categoria C</option>
    </select>

    <label for="order">Ordenar por:</label>
    <select name="order" id="order">
        <option value="default" { $orderBy = 'default'}>Sin orden</option>
        <option value="price" { $orderBy = 'price' }>Precio </option>
    </select>

    <button type="submit">Aplicar Filtros</button>
</form>

<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Descripción</th>
            <th>Unidades</th>
            <th>Precio</th>
            <th>Categoría</th>
        </tr>
    </thead>
    <tbody>
        @foreach($productos as $producto)
        <tr>
            <td>{{ $producto->id }}</td>
            <td>{{ $producto->nombre }}</td>
            <td>{{ $producto->descripcion }}</td>
            <td>{{ $producto->unidades }}</td>
            <td>{{ $producto->precio_unitario }}</td>
            <td>{{ $producto->categoria }}</td>
        </tr>
        @endforeach
    </tbody>
</table><br><br>

<a href="{{ route('menuUser.pagPrincipal') }}"><button>Volver</button></a>
