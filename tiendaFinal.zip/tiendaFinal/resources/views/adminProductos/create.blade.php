<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <h2>Productos</h2>
                <div class="card-body">
                    <form method="POST" action="{{ route('adminProductos.store') }}">
                        @csrf
                        <br>
                        <div class="form-group">
                            <label for="nombre">Nombre</label>
                            <input type="text" name="nombre" id="nombre" class="form-control" required>
                        </div><br>

                        <div class="form-group">
                            <label for="descripcion">Descripción</label>
                            <input type="text" name="descripcion" id="descripcion" class="form-control" required>
                        </div><br>

                        <div class="form-group">
                            <label for="unidades">Unidades</label>
                            <input type="text" name="unidades" id="unidades" class="form-control" required>
                        </div><br>

                        <div class="form-group">
                            <label for="precio_unitario">Precio Unitario</label>
                            <input type="text" name="precio_unitario" id="precio_unitario" class="form-control" required>
                        </div><br>

                        <div class="form-group">
                            <label for="categoria">Categoría</label>
                            <select name="categoria" id="categoria" class="form-control" >
                                <option value="Categoria A">Categoria A</option>
                                <option value="Categoria B">Categoria B</option>
                                <option value="Categoria C">Categoria C</option>
                            </select>
                        </div><br>

                        <button type="submit" class="btn btn-primary">Crear Producto</button><br><br>

                        <a href="{{ route('adminProductos.index') }}">Volver</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>