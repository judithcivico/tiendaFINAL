<style>
    table {
        border-collapse: collapse;
        width: 800px;
    }

    table, th, td {
        border: 1px solid black;
    }

    th, td {
        padding: 5px;
        text-align: left;
    }
</style>
<main>
    <div class="container">
        <h2>Administrar productos</h2>

        <a href="{{url('adminProductos/create')}}">Nuevo producto</a><br><br>

        <table class="table table-hover border">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Descripción</th>
                    <th>Unidades</th>
                    <th>Precio</th>
                    <th>Categoría</th>
                </tr>
            </thead>
            
            <tbody>
                @foreach ($productos as $producto)
                    <tr>
                        <td>{{$producto->id}}</td>
                        <td>{{$producto->nombre}}</td>
                        <td>{{$producto->descripcion}}</td>
                        <td>{{$producto->unidades}}</td>
                        <td>{{$producto->precio_unitario}}</td>
                        <td>{{$producto->categoria}}</td>
                        <td><a href="{{ route('adminProductos.edit', ['id' => $producto->id]) }}"><button>Editar</button></a></td>
                        <td><form action="{{url('adminProductos/'.$producto->id)}}" method="POST">
                                @method("DELETE")
                                @csrf
                                <button type="submit">Eliminar</button>
                            </form>
                        </td>     
                    </tr>
                @endforeach
            </tbody>
        </table><br><br>
        <a href="{{ route('menuAdmin.index') }}"><button>Volver</button></a>
    </div>
</main>
