<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <h2>Productos</h2>
                <div class="card-body">
                    <form method="POST" action="{{ url('adminProductos/'.$producto->id) }}">
                        @method("PUT")
                        @csrf
                        <br>
                        <div class="form-group">
                            <label for="nombre">Nombre</label>
                            <input type="text" name="nombre" id="nombre" class="form-control" value="{{$producto->nombre}}" required>
                        </div><br>

                        <div class="form-group">
                            <label for="descripcion">Descripción</label>
                            <input type="text" name="descripcion" id="descripcion" class="form-control" value="{{$producto->descripcion}}">
                        </div><br>

                        <div class="form-group">
                            <label for="unidades">Unidades</label>
                            <input type="number" name="unidades" id="unidades" class="form-control" value="{{$producto->unidades}}">
                        </div><br>

                        <div class="form-group">
                            <label for="precio_unitario">Precio Unitario</label>
                            <input type="number" name="precio_unitario" id="precio_unitario" class="form-control" value="{{$producto->precio_unitario}}">
                        </div><br>

                        <div class="form-group">
                            <label for="categoria">Categoría</label>
                            <select name="categoria" id="categoria" class="form-control" >
                                <option value="Categoria A" {{ $producto->categoria == 'Categoria A' ? 'selected' : '' }}>Categoria A</option>
                                <option value="Categoria B" {{ $producto->categoria == 'Categoria B' ? 'selected' : '' }}>Categoria B</option>
                                <option value="Categoria C" {{ $producto->categoria == 'Categoria C' ? 'selected' : '' }}>Categoria C</option>
                            </select>
                        </div><br>

                        <button type="submit" class="btn btn-primary">Editar Producto</button>

                        <a href="{{ url('pokemon') }}">Volver</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
