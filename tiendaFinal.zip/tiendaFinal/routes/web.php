<?php

use App\Http\Controllers\CatalogoController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\RegisterController;
use App\Http\Controllers\UsuarioController;
use App\Http\Controllers\AdminProductoController; 
use App\Http\Controllers\AdminUserController; 
use App\Http\Controllers\AdminCategoriasController; 
use App\Http\Controllers\CategoriaController; 
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

// Rutas para el controlador LoginController
Route::get('/login', [LoginController::class, 'index'])->name('login.index');
Route::post('/login', [LoginController::class, 'login'])->name('login.authenticate');

// Rutas para el controlador RegisterController
Route::get('/register', [RegisterController::class, 'index'])->name('register.index');
Route::post('/register', [RegisterController::class, 'store'])->name('usuarios.store');


Route::post('/login', [LoginController::class, 'login'])->name('login.submit');
Route::post('/logout', [LoginController::class, 'logout'])->name('logout');


Route::middleware(['auth'])->group(function () {
    Route::get('/dashboard', [LoginController::class, 'dashboard'])->name('dashboard');

    //USUARIO
    Route::middleware(['role:usuario'])->group(function () {
        Route::get('/menuUser', [LoginController::class, 'index'])->name('menuUser.index');

        Route::get('/menuUser', [UsuarioController::class, 'showProfile'])->name('user-profile.show');
        Route::post('/menuUser', [UsuarioController::class, 'updateProfile'])->name('user-profile.update');

        //VOLVER
        Route::get('/menuUser/pagPrincipal', function () {
            return view('menuUser.pagPrincipal');
        })->name('menuUser.pagPrincipal');
    });

    //ADMIN
    Route::middleware(['role:administrador'])->group(function () {
        Route::get('/admin', [LoginController::class, 'index'])->name('menuAdmin.index');
        
        Route::resource('adminProductos', AdminProductoController::class);
        Route::get('/adminProductos/{id}/edit', [AdminProductoController::class, 'edit'])->name('adminProductos.edit');
        
        
        Route::resource('adminUsers', AdminUserController::class);
        Route::get('/adminUsers/{id}/edit', [AdminUserController::class, 'edit'])->name('adminUsers.edit');

        Route::resource('adminCategorias', AdminCategoriasController::class);
        Route::get('/adminCategorias/{id}/edit', [AdminCategoriasController::class, 'edit'])->name('adminCategorias.edit');


        //VOLVER
        Route::get('/menuAdmin', function () {
            return view('admin.menuAdmin');
        })->name('menuAdmin.index');

        Route::get('/menuUser', function () {
            return view('admin.menuAdmin');
        })->name('menuUser.index');
    });
});

Route::get('/menuUser', [UsuarioController::class, 'showUsu']);


Route::get('/catalog', [CatalogoController::class, 'showCatalog']);
Route::get('/catalog/ordenar-precio', [CatalogoController::class, 'ordenarPorPrecio']);

Route::get('/categorias', [CategoriaController::class, 'index'])->name('categorias.index');


//Route::get('/categories', [CategoriaController::class, 'showCategories']);
//Route::get('/cart', [CarritoController::class, 'showCart']);
