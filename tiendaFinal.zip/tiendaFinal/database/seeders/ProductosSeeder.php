<?php

namespace Database\Seeders;

use App\Models\Producto;
use Illuminate\Database\Seeder;

class ProductosSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run()
    {
        $categoria = ['Categoria A', 'Categoria B', 'Categoria C'];
        // Crear 10 productos aleatorios
        for ($i = 1; $i <= 10; $i++) {
            Producto::create([
                'nombre' => 'Producto ' . $i,
                'descripcion' => 'Descripción Producto ' . $i,
                'unidades' => rand(50, 200), // Cantidad aleatoria entre 50 y 200 unidades
                'precio_unitario' => rand(5, 50), // Precio aleatorio entre 5 y 50
                'categoria' => $categoria[array_rand($categoria)], // Seleccionar aleatoriamente una categoría del array
            ]);
        }
    }
}