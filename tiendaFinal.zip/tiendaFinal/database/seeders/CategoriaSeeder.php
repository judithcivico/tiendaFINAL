<?php

namespace Database\Seeders;

use App\Models\Categoria;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class CategoriaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run()
    {
        Categoria::create([
            'nombre' => 'Categoria A',
            'descripcion' => 'Description Categoria A',
        ]);

        // Add more categories as needed
    }
}
