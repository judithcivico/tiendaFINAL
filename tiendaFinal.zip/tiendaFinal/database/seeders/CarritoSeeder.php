<?php

namespace Database\Seeders;

use App\Models\Carrito;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class CarritoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run()
    {
        Carrito::create([
            'cantidad' => 2,
            'precio_producto' => 10.99,
            'total' => 21.98,
        ]);

        // Add more cart items as needed
    }
}