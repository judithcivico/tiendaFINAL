<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\User;

class UsersSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        User::create([
            'nick' => 'usuario',
            'email' => 'usu@usu.com',
            'nombre' => 'usu',
            'apellido' => 'ario',
            'dni' => '36763198e',
            'fecha_nacimiento' => '2003-04-21',
            'password' => '1234',
            'role' => 'usuario'
        ]);
        User::create([
            'nick' => 'admin',
            'email' => 'admin@admin.com',
            'nombre' => 'ad',
            'apellido' => 'min',
            'dni' => '37648990s',
            'fecha_nacimiento' => '1995-10-01',
            'password' => '1234',
            'role' => 'administrador'
        ]);
}
}