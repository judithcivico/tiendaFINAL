<?php

namespace App\Http\Controllers;

use App\Models\Producto;
use Illuminate\Http\Request;

class CatalogoController extends Controller
{
    public function showCatalog(Request $request)
    {
        // Recuperar la categoría seleccionada y el orden
        $categoryFilter = $request->input('category');
        $orderBy = $request->input('order', 'default'); // default es para mostrar desordenado

        // Construir la consulta
        $query = Producto::query();
        
        // Filtrar por categoría
        if ($categoryFilter) {
            $query->where('categoria', $categoryFilter);
        }

        // Ordenar por precio
        if ($orderBy == 'price') {
            $query->orderBy('precio_unitario');
        }

        // Obtener los productos
        $productos = $query->get();

        return view('catalog.show', compact('productos'));
    }
}
