<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Producto;

class AdminProductoController extends Controller
{
    public function index()
    {
        // Muestra la lista de todos los productos
        $productos = Producto::all();
        return view('adminProductos.index', compact('productos'));
    }

    public function create()
    {
        // Muestra el formulario para crear un nuevo producto
        return view('adminProductos.create');
    }

    public function store(Request $request)
    {
        // Almacena un nuevo producto en la base de datos
        $request->validate([
            'nombre' => 'required|string|max:255',
            'descripcion' => 'required|string',
            'unidades' => 'required|integer|min:1',
            'precio_unitario' => 'required|numeric|min:0',
            'categoria' => 'required|string',
        ]);

        // Crear un nuevo producto
        $producto = Producto::create([
            'nombre' => $request->input('nombre'),
            'descripcion' => $request->input('descripcion'),
            'unidades' => $request->input('unidades'),
            'precio_unitario' => $request->input('precio_unitario'),
            'categoria' => $request->input('categoria'),
        ]);

        return redirect()->route('adminProductos.index')->with('success', 'Producto creado correctamente');
    }

    public function show($id)
    {
        // Muestra los detalles de un producto específico
        $producto = Producto::findOrFail($id);
        return view('adminProductos.show', compact('producto'));
    }

    public function edit($id)
    {
        // Muestra el formulario para editar un producto específico
        $producto = Producto::findOrFail($id);
        return view('adminProductos.edit', compact('producto'));
    }

    public function update(Request $request, $id)
    {
        // Actualiza un producto en la base de datos
        $request->validate([
            'nombre' => 'required|string|max:255',
            'descripcion' => 'required|string',
            'unidades' => 'required|integer|min:1',
            'precio_unitario' => 'required|numeric|min:0',
            'categoria' => 'required|string',
        ]);

        $producto = Producto::findOrFail($id);
        $producto->update($request->all());

        return redirect()->route('adminProductos.index')->with('success', 'Producto actualizado correctamente');
    }

    public function destroy($id)
    {
        // Elimina un producto de la base de datos
        $producto = Producto::find($id);
        $producto->delete();

        return redirect()->route('adminProductos.index')->with('success', 'Producto eliminado correctamente');
    }
}
