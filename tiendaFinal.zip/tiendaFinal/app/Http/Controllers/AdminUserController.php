<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;

class AdminUserController extends Controller
{
    public function index()
    {
        // Muestra la lista de todos los productos
        $users = User::all();
        return view('adminUsers.index', compact('users'));
    }

    public function create()
    {
        // Muestra el formulario para crear un nuevo producto
        return view('adminUsers.create');
    }

    public function store(Request $request)
    {
        // Almacena un nuevo producto en la base de datos
        $request->validate([
            'nick' => 'required|string|max:255',
            'nombre' => 'required|string|max:255',
            'apellido' => 'required|string|max:255',
            'email' => 'required|string|max:255',
            'password' => 'nullable|string',
            'role' => 'required|string|max:255',
            'dni' => 'required|string|max:255',
            'fecha_nacimiento' => 'required|string|max:255',
        ]);

        // Crear un nuevo producto
        $usuario = User::create([
            'nick' => $request->input('nick'),
            'nombre' => $request->input('nombre'),
            'apellido' => $request->input('apellido'),
            'email' => $request->input('email'),
            'password' => $request->input('password'),
            'role' => $request->input('role'),
            'dni' => $request->input('dni'),
            'fecha_nacimiento' => $request->input('fecha_nacimiento'),
        ]);

        return redirect()->route('adminUsers.index')->with('success', 'Producto creado correctamente');
    }

    public function show($id)
    {
        // Muestra los detalles de un producto específico
        $user = User::findOrFail($id);
        return view('adminUsers.show', compact('user'));
    }

    public function edit($id)
    {
        // Muestra el formulario para editar un producto específico
        $user = User::findOrFail($id);
        return view('adminUsers.edit', compact('user'));
    }

    public function update(Request $request, $id)
    {
        // Actualiza un producto en la base de datos
        $request->validate([
            'nick' => 'required|string|max:255',
            'nombre' => 'required|string|max:255',
            'apellido' => 'required|string|max:255',
            'email' => 'required|string|max:255',
            'password' => 'nullable|string',
            'role' => 'required|string|max:255',
            'dni' => 'required|string|max:255',
            'fecha_nacimiento' => 'required|string|max:255',
        ]);

        $user = User::findOrFail($id);
        $user->update($request->all());

        return redirect()->route('adminUsers.index')->with('success', 'Usuario actualizado correctamente');
    }

    public function destroy($id)
    {
        // Elimina un producto de la base de datos
        $user = User::find($id);
        $user->delete();

        return redirect()->route('adminUsers.index')->with('success', 'Usuario eliminado correctamente');
    }
}
