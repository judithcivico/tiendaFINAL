<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class UsuarioController extends Controller
{
    public function showUsu()
    {
        // Recupera el usuario autenticado
        $user = Auth::user();

        // Muestra la vista correspondiente al perfil del usuario
        return view('editUsu.show', compact('user'));
    }

    public function updateProfile(Request $request)
    {
        // Valida los datos del formulario
        $request->validate([
            'nick' => 'required|string|max:255',
            'nombre' => 'required|string|max:255',
            'apellido' => 'required|string|max:255',
            'email' => 'required|string|email|max:255',
            'dni' => 'required|string|max:255',
            'fecha_nacimiento' => 'required|date',
        ]);

        // Recupera el usuario autenticado
        $user = Auth::user();

        // Actualiza la información del usuario
        $user->update([
            'nick' => $request->input('nick'),
            'nombre' => $request->input('nombre'),
            'apellido' => $request->input('apellido'),
            'email' => $request->input('email'),
            'dni' => $request->input('dni'),
            'fecha_nacimiento' => $request->input('fecha_nacimiento'),
        ]);

        return redirect()->route('menuUser.pagPrincipal')->with('success', 'Perfil actualizado correctamente');
    }
}
