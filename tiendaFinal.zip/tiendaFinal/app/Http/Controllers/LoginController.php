<?php

namespace App\Http\Controllers;

use App\Models\LoginModel;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Auth;

class LoginController extends Controller
{
    public function index()
    {
        return view('login.login');
    }

    // verificar los datos introducidos y autenticar al usuario
    public function login(Request $request)
    {
        $credentials = $request->only('email', 'password');
    
        $user = User::where('email', $credentials['email'])->first();
    
        if ($user && $user->password === $credentials['password']) {
            Auth::login($user);
            return redirect()->intended('/dashboard');
        }
    
        return back()->withErrors(['email' => 'Invalid credentials']);
    }
    
    // dependiendo del rol del usuario, utiliza auth::user() para obtener al usuario y luego verifica su rol 
    public function dashboard()
    {

        $user = Auth::user();

        if ($user->role == 'administrador') {
            return view('admin.menuAdmin');
        } elseif ($user->role == 'usuario') {
            return view('menuUser.pagPrincipal');
        }
    }

    // cerrar sesión
    public function logout(Request $request)
    {
        Auth::logout();

        $request->session()->invalidate();

        return redirect('/login');
    }

}
