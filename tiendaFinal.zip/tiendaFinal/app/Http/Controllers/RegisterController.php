<?php

// app/Http/Controllers/RegisterController.php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Log;

class RegisterController extends Controller
{
    public function index()
    {
        return view('login.register');
    }

    // valida los datos pasados por pantalla
    public function store(Request $request)
    {
        $request->validate([
            'nombre' => 'required|max:255',
            'nick' => 'required|max:255',
            'apellido' => 'required|max:255',
            'email' => 'required|email|unique:users|max:255',
            'password' => 'required|max:255',
            'role' => 'required|max:255',
            'fecha_nacimiento' => 'required|date|max:255',
            'dni' => 'required|max:255',
        ]);

        $usuario = new User([
            'nombre' => $request->input('nombre'),
            'nick' => $request->input('nick'),
            'apellido' => $request->input('apellido'),
            'email' => $request->input('email'),
            'password' => $request->input('password'),
            'role' => $request->input('role'),
            'fecha_nacimiento' => $request->input('fecha_nacimiento'),
            'dni' => $request->input('dni'),
        ]);

        $usuario->save();

        return redirect()->route('login.index')->with('success', 'Usuario creado correctamente');
    }
}
