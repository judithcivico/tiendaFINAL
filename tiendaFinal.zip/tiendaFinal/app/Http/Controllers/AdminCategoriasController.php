<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Categoria;

class AdminCategoriasController extends Controller
{
    public function index()
    {
        // Muestra la lista de todos los categorias
        $categorias = Categoria::all();
        return view('adminCategorias.index', compact('categorias'));
    }

    public function create()
    {
        // Muestra el formulario para crear una nueva categoria
        return view('adminCategorias.create');
    }

    public function store(Request $request)
    {
        // Almacena un nueva categoria en la base de datos
        $request->validate([
            'nombre' => 'required|string|max:255',
            'descripcion' => 'required|string',
        ]);

        // Crear un nueva categoria
        $categoria = Categoria::create([
            'nombre' => $request->input('nombre'),
            'descripcion' => $request->input('descripcion'),
        ]);

        return redirect()->route('adminCategorias.index')->with('success', 'Categoria creado correctamente');
    }

    public function show($id)
    {
        // Muestra los detalles de una categoria específico
        $categoria = Categoria::findOrFail($id);
        return view('adminCategorias.show', compact('categoria'));
    }

    public function edit($id)
    {
        // Muestra el formulario para editar una categoria específico
        $categoria = Categoria::findOrFail($id);
        return view('adminCategorias.edit', compact('categoria'));
    }

    public function update(Request $request, $id)
    {
        // Actualiza una categoria en la base de datos
        $request->validate([
            'nombre' => 'required|string|max:255',
            'descripcion' => 'required|string',
        ]);

        $categoria = Categoria::findOrFail($id);
        $categoria->update($request->all());

        return redirect()->route('adminCategorias.index')->with('success', 'Categoria actualizado correctamente');
    }

    public function destroy($id)
    {
        // Elimina un categoria de la base de datos
        $categoria = Categoria::find($id);
        $categoria->delete();

        return redirect()->route('adminCategorias.index')->with('success', 'Categoria eliminado correctamente');
    }
}
