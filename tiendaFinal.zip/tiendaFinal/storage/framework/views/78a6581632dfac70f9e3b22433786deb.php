<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <h2>Usuarios</h2>
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('usuarios.store')); ?>">
                        <?php echo csrf_field(); ?>
                        <br>
                        <div class="form-group">
                            <label for="nick">Nick</label>
                            <input type="text" name="nick" id="nick" class="form-control" required>
                        </div><br>

                        <div class="form-group">
                            <label for="nombre">Nombre</label>
                            <input type="text" name="nombre" id="nombre" class="form-control" required>
                        </div><br>

                        <div class="form-group">
                            <label for="apellido">Apellido</label>
                            <input type="text" name="apellido" id="apellido" class="form-control" required>
                        </div><br>

                        <div class="form-group">
                            <label for="email">Correo Electrónico</label>
                            <input type="email" name="email" id="email" class="form-control" required>
                        </div><br>

                        <div class="form-group">
                            <label for="password">Contraseña</label>
                            <input type="password" name="password" id="password" class="form-control" required>
                        </div><br>

                        <div class="form-group">
                            <label for="role">Rol</label>
                            <input type="text" name="role" id="role" class="form-control" required>
                        </div><br>

                        <div class="form-group">
                            <label for="dni">DNI</label>
                            <input type="text" name="dni" id="dni" class="form-control" required>
                        </div><br>

                        <div class="form-group">
                            <label for="fecha_nacimiento">Fecha de Nacimiento</label>
                            <input type="date" name="fecha_nacimiento" id="fecha_nacimiento" class="form-control" required>
                        </div><br>

                        <button type="submit" class="btn btn-primary">Crear Usuario</button><br><br>

                        <a href="<?php echo e(route('usuarios.index')); ?>">Volver</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Judith\Downloads\Xd\resources\views/adminUsers/create.blade.php ENDPATH**/ ?>