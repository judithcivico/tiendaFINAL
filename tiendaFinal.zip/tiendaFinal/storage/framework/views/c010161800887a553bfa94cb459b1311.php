<body>
    <h1>Hola Admin</h1>
    <a href="<?php echo e(url('/adminProductos')); ?>"><button>Administrar productos</button></a>
    <a href="<?php echo e(url('/adminCategorias')); ?>"><button>Administrar categorias</button></a>
    <a href="<?php echo e(url('/adminUsers')); ?>"><button>Administrar usuarios</button></a><br><br>

    <?php if(auth()->guard()->check()): ?>
        <form id="logout-form" method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
            <button type="button" onclick="confirmLogout()">Logout</button>
        </form>

        <script>
            function confirmLogout() {
                if (confirm('¿Estás seguro de que deseas cerrar sesión?')) {
                    document.getElementById('logout-form').submit();
                }
            }
        </script>
    <?php endif; ?>
</body>
<?php /**PATH C:\xampp\htdocs\Xd\resources\views/admin/menuAdmin.blade.php ENDPATH**/ ?>