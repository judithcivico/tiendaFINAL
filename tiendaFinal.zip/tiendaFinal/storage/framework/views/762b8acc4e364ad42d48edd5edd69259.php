<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <h2>Productos</h2>
                <div class="card-body">
                    <form method="POST" action="<?php echo e(url('adminProductos/'.$producto->id)); ?>">
                        <?php echo method_field("PUT"); ?>
                        <?php echo csrf_field(); ?>
                        <br>
                        <div class="form-group">
                            <label for="nombre">Nombre</label>
                            <input type="text" name="nombre" id="nombre" class="form-control" value="<?php echo e($producto->nombre); ?>" required>
                        </div><br>

                        <div class="form-group">
                            <label for="descripcion">Descripción</label>
                            <input type="text" name="descripcion" id="descripcion" class="form-control" value="<?php echo e($producto->descripcion); ?>">
                        </div><br>

                        <div class="form-group">
                            <label for="unidades">Unidades</label>
                            <input type="number" name="unidades" id="unidades" class="form-control" value="<?php echo e($producto->unidades); ?>">
                        </div><br>

                        <div class="form-group">
                            <label for="precio_unitario">Precio Unitario</label>
                            <input type="number" name="precio_unitario" id="precio_unitario" class="form-control" value="<?php echo e($producto->precio_unitario); ?>">
                        </div><br>

                        <div class="form-group">
                            <label for="categoria">Categoría</label>
                            <select name="categoria" id="categoria" class="form-control" >
                                <option value="Categoria A" <?php echo e($producto->categoria == 'Categoria A' ? 'selected' : ''); ?>>Categoria A</option>
                                <option value="Categoria B" <?php echo e($producto->categoria == 'Categoria B' ? 'selected' : ''); ?>>Categoria B</option>
                                <option value="Categoria C" <?php echo e($producto->categoria == 'Categoria C' ? 'selected' : ''); ?>>Categoria C</option>
                            </select>
                        </div><br>

                        <button type="submit" class="btn btn-primary">Editar Producto</button>

                        <a href="<?php echo e(url('pokemon')); ?>">Volver</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Judith\Downloads\Xd\resources\views/adminProductos/edit.blade.php ENDPATH**/ ?>