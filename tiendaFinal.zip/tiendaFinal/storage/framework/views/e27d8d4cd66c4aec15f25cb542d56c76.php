<!-- resources/views/catalog/show.blade.php -->
<style>
    table {
        border-collapse: collapse;
        width: 800px;
    }

    table, th, td {
        border: 1px solid black;
    }

    th, td {
        padding: 5px;
        text-align: left;
    }
</style>
<h1>Catálogo de Productos</h1>

<form action="<?php echo e(url('/catalog')); ?>" method="get" id="filterForm">
    <?php echo csrf_field(); ?>
    <label for="category">Buscar por categoría:</label>
    <select name="category" id="category" >
        <option value="" { $categoryFilter = '' }>Mostrar Todos</option>
        <option value="Categoria A" { $categoryFilter = 'Categoria A' }>Categoria A</option>
        <option value="Categoria B" { $categoryFilter = 'Categoria B' }>Categoria B</option>
        <option value="Categoria C" { $categoryFilter ='Categoria C' }>Categoria C</option>
    </select>

    <label for="order">Ordenar por:</label>
    <select name="order" id="order">
        <option value="default" { $orderBy = 'default'}>Sin orden</option>
        <option value="price" { $orderBy = 'price' }>Precio </option>
    </select>

    <button type="submit">Aplicar Filtros</button>
</form>

<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Descripción</th>
            <th>Unidades</th>
            <th>Precio</th>
            <th>Categoría</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($producto->id); ?></td>
            <td><?php echo e($producto->nombre); ?></td>
            <td><?php echo e($producto->descripcion); ?></td>
            <td><?php echo e($producto->unidades); ?></td>
            <td><?php echo e($producto->precio_unitario); ?></td>
            <td><?php echo e($producto->categoria); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><br><br>

<a href="<?php echo e(route('menuUser.pagPrincipal')); ?>"><button>Volver</button></a>
<?php /**PATH C:\Users\Judith\Downloads\Xd\resources\views/catalog/show.blade.php ENDPATH**/ ?>