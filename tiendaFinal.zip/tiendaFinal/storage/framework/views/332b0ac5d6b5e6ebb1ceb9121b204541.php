<body>
    <form action="<?php echo e(url('/menuUser')); ?>" method="post">
        <?php echo csrf_field(); ?> <!-- Agregar el token CSRF -->

        <label for="nick">Nick:</label>
        <input type="text" id="nick" name="nick" value="<?php echo e(auth()->user()->nick); ?>" /><br><br>

        <label for="nombre">Nombre:</label>
        <input type="text" id="nombre" name="nombre" value="<?php echo e(auth()->user()->nombre); ?>" /><br><br>

        <label for="apellido">Apellido:</label>
        <input type="text" id="apellido" name="apellido" value="<?php echo e(auth()->user()->apellido); ?>" /><br><br>

        <label for="email">Correo electrónico:</label>
        <input type="email" id="email" name="email" value="<?php echo e(auth()->user()->email); ?>" /><br><br>

        <label for="rol">Rol:</label>
        <input type="text" id="rol" name="rol" value="<?php echo e(auth()->user()->role); ?>" /><br><br>

        <label for="dni">DNI:</label>
        <input type="text" id="dni" name="dni" value="<?php echo e(auth()->user()->dni); ?>" /><br><br>

        <label for="fecha_nacimiento">Fecha de nacimiento:</label>
        <input type="date" id="fecha_nacimiento" name="fecha_nacimiento" value="<?php echo e(auth()->user()->fecha_nacimiento); ?>" /><br><br>

        <button type="submit">Actualizar Perfil</button><br><br>

        <a href="<?php echo e(route('menuUser.pagPrincipal')); ?>">Volver</a>

    </form>
</body>
<?php /**PATH C:\xampp\htdocs\Xd\resources\views/editUsu/show.blade.php ENDPATH**/ ?>