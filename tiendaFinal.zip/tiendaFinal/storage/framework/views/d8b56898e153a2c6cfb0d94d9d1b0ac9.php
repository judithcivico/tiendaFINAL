<style>
    table {
        border-collapse: collapse;
        width: 1000px;
    }

    table, th, td {
        border: 1px solid black;
    }

    th, td {
        padding: 5px;
        text-align: left;
    }
</style>

<main>
    <div class="container">
        <h2>Administrar usuarios</h2>

        <a href="<?php echo e(route('adminUsers.create')); ?>">Nuevo producto</a><br><br>

        <table class="table table-hover border">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nick</th>
                    <th>Nombre</th>
                    <th>Apellido</th>
                    <th>Correo</th>
                    <th>Role</th>
                    <th>DNI</th>
                    <th>Fecha nacimiento</th>
                </tr>
            </thead>

            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($user->id); ?></td>
                        <td><?php echo e($user->nick); ?></td>
                        <td><?php echo e($user->nombre); ?></td>
                        <td><?php echo e($user->apellido); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->role); ?></td>
                        <td><?php echo e($user->dni); ?></td>
                        <td><?php echo e($user->fecha_nacimiento); ?></td>
                        <td><a href="<?php echo e(route('adminUsers.edit', ['id' => $user->id])); ?>"><button>Editar</button></a></td>
                        <td><form action="<?php echo e(url('adminUsers/'.$user->id)); ?>" method="POST">
                                <?php echo method_field("DELETE"); ?>
                                <?php echo csrf_field(); ?>
                                <button type="submit">Eliminar</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table><br><br>
        
        <a href="<?php echo e(route('menuAdmin.index')); ?>"><button>Volver</button></a>
    </div>
</main>
<?php /**PATH C:\Users\Judith\Downloads\Xd\resources\views/adminUsers/index.blade.php ENDPATH**/ ?>