<!-- resources/views/catalog/show.blade.php -->
<style>
    table {
        border-collapse: collapse;
        width: 800px;
    }

    table, th, td {
        border: 1px solid black;
    }

    th, td {
        padding: 5px;
        text-align: left;
    }
</style>
<h2>Categorías</h2>
<table>
    <thead>
        <tr>
            <th>Nombre</th>
            <th>Descripción</th>
            <th>Fecha</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($categoria->nombre); ?></td>
            <td><?php echo e($categoria->descripcion); ?></td>
            <td><?php echo e($categoria->created_at); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><br><br>

<a href="<?php echo e(route('menuUser.pagPrincipal')); ?>"><button>Volver</button></a>
<?php /**PATH C:\xampp\htdocs\Xd\resources\views/categoria/show.blade.php ENDPATH**/ ?>