<form action="<?php echo e(url('/catalog')); ?>" method="get">
        <?php echo csrf_field(); ?>
        <label for="category">Buscar por categoría:</label>
        <input type="text" name="category" id="category">
        <button type="submit">Buscar</button>
    </form>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Descripción</th>
                <th>Unidades</th>
                <th>Precio Unitario</th>
                <th>Categoría</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($producto->id); ?></td>
            <td><?php echo e($producto->nombre); ?></td>
            <td><?php echo e($producto->descripcion); ?></td>
            <td><?php echo e($producto->unidades); ?></td>
            <td><?php echo e($producto->precio_unitario); ?></td>
            <td><?php echo e($producto->categoria); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table><?php /**PATH C:\xampp\htdocs\Xd\resources\views/show.blade.php ENDPATH**/ ?>