<style>
    table {
        border-collapse: collapse;
        width: 800px;
    }

    table, th, td {
        border: 1px solid black;
    }

    th, td {
        padding: 5px;
        text-align: left;
    }
</style>
<main>
    <div class="container">
        <h2>Administrar productos</h2>

        <a href="<?php echo e(url('adminCategorias/create')); ?>">Nuevo producto</a><br><br>

        <table class="table table-hover border">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Descripción</th>
                </tr>
            </thead>
            
            <tbody>
                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($categoria->id); ?></td>
                        <td><?php echo e($categoria->nombre); ?></td>
                        <td><?php echo e($categoria->descripcion); ?></td>
                        <td><a href="<?php echo e(route('adminCategorias.edit', ['id' => $categoria->id])); ?>"><button>Editar</button></a></td>
                        <td><form action="<?php echo e(url('adminCategorias/'.$categoria->id)); ?>" method="POST">
                                <?php echo method_field("DELETE"); ?>
                                <?php echo csrf_field(); ?>
                                <button type="submit">Eliminar</button>
                            </form>
                        </td>     
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table><br><br>
        <a href="<?php echo e(route('menuAdmin.index')); ?>"><button>Volver</button></a>
    </div>
</main>
<?php /**PATH C:\xampp\htdocs\Xd\resources\views/adminCategorias/index.blade.php ENDPATH**/ ?>