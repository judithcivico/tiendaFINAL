<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <h2>Usuarios</h2>
                <div class="card-body">
                    <form method="POST" action="<?php echo e(url('adminUsers/'.$user->id)); ?>">
                        <?php echo method_field("PUT"); ?>
                        <?php echo csrf_field(); ?>
                        <br>
                        <div class="form-group">
                            <label for="nick">Nick</label>
                            <input type="text" name="nick" id="nick" class="form-control" value="<?php echo e($user->nick); ?>" required>
                        </div><br>

                        <div class="form-group">
                            <label for="nombre">Nombre</label>
                            <input type="text" name="nombre" id="nombre" class="form-control" value="<?php echo e($user->nombre); ?>" required>
                        </div><br>

                        <div class="form-group">
                            <label for="apellido">Apellido</label>
                            <input type="text" name="apellido" id="apellido" class="form-control" value="<?php echo e($user->apellido); ?>">
                        </div><br>

                        <div class="form-group">
                            <label for="email">Correo Electrónico</label>
                            <input type="email" name="email" id="email" class="form-control" value="<?php echo e($user->email); ?>" required>
                        </div><br>

                        <div class="form-group">
                            <label for="password">Contraseña</label>
                            <input type="password" name="password" id="password" class="form-control">
                        </div><br>

                        <div class="form-group">
                            <label for="role">Rol</label>
                            <select name="role" id="role" class="form-control">
                                <option value="usuario" <?php echo e($user->role == 'usuario' ? 'selected' : ''); ?>>Usuario</option>
                                <option value="administrador" <?php echo e($user->role == 'administrador' ? 'selected' : ''); ?>>Administrador</option>
                            </select>
                        </div><br>

                        <div class="form-group">
                            <label for="dni">DNI</label>
                            <input type="text" name="dni" id="dni" class="form-control" value="<?php echo e($user->dni); ?>">
                        </div><br>

                        <div class="form-group">
                            <label for="fecha_nacimiento">Fecha de Nacimiento</label>
                            <input type="date" name="fecha_nacimiento" id="fecha_nacimiento" class="form-control" value="<?php echo e($user->fecha_nacimiento); ?>">
                        </div><br>

                        <button type="submit" class="btn btn-primary">Editar Usuario</button>

                        <a href="<?php echo e(route('adminUsers.index')); ?>">Volver</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Judith\Downloads\Xd\resources\views/adminUsers/edit.blade.php ENDPATH**/ ?>