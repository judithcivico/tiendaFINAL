<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Hola Usuario</h1>
    <a href="<?php echo e(url('/menuUser')); ?>"><button>Perfil de usuario</button></a>
    <a href="<?php echo e(url('/catalog')); ?>"><button>Catalogo de productos</button></a>
    <a href="<?php echo e(url('/categorias')); ?>"><button>Categorias</button></a>
    <a href="<?php echo e(url('/cart')); ?>"><button>Carrito</button></a><br><br>
</body>

<?php if(auth()->guard()->check()): ?>
    <form id="logout-form" method="POST" action="<?php echo e(route('logout')); ?>">
        <?php echo csrf_field(); ?>
        <button type="button" onclick="confirmLogout()">Logout</button>
    </form>

    <script>
        function confirmLogout() {
            if (confirm('¿Estás seguro de que deseas cerrar sesión?')) {
                document.getElementById('logout-form').submit();
            }
        }
    </script>
<?php endif; ?>
</html><?php /**PATH C:\xampp\htdocs\Xd\resources\views/menuUser/pagPrincipal.blade.php ENDPATH**/ ?>