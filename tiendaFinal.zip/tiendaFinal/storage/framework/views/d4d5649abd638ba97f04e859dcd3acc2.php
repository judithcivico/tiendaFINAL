<style>
    table {
        border-collapse: collapse;
        width: 800px;
    }

    table, th, td {
        border: 1px solid black;
    }

    th, td {
        padding: 5px;
        text-align: left;
    }
</style>
<main>
    <div class="container">
        <h2>Administrar productos</h2>

        <a href="<?php echo e(url('adminProductos/create')); ?>">Nuevo producto</a><br><br>

        <table class="table table-hover border">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Descripción</th>
                    <th>Unidades</th>
                    <th>Precio</th>
                    <th>Categoría</th>
                </tr>
            </thead>
            
            <tbody>
                <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($producto->id); ?></td>
                        <td><?php echo e($producto->nombre); ?></td>
                        <td><?php echo e($producto->descripcion); ?></td>
                        <td><?php echo e($producto->unidades); ?></td>
                        <td><?php echo e($producto->precio_unitario); ?></td>
                        <td><?php echo e($producto->categoria); ?></td>
                        <td><a href="<?php echo e(route('adminProductos.edit', ['id' => $producto->id])); ?>"><button>Editar</button></a></td>
                        <td><form action="<?php echo e(url('adminProductos/'.$producto->id)); ?>" method="POST">
                                <?php echo method_field("DELETE"); ?>
                                <?php echo csrf_field(); ?>
                                <button type="submit">Eliminar</button>
                            </form>
                        </td>     
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table><br><br>
        <a href="<?php echo e(route('menuAdmin.index')); ?>"><button>Volver</button></a>
    </div>
</main>
<?php /**PATH C:\xampp\htdocs\Xd\resources\views/adminProductos/index.blade.php ENDPATH**/ ?>