<body>
    <form action="<?php echo e(url('/user-profile')); ?>" method="post">
        <label for="nick">Nick:</label>
        <input type="text" id="nick" name="nick" />

        <label for="nombre">Nombre:</label>
        <input type="text" id="nombre" name="nombre" />

        <label for="apellido">Apellido:</label>
        <input type="text" id="apellido" name="apellido" />

        <label for="email">Correo electrónico:</label>
        <input type="email" id="email" name="email" />

        <label for="rol">Rol:</label>
        <input type="text" id="rol" name="rol" />

        <label for="dni">DNI:</label>
        <input type="text" id="dni" name="dni" />

        <label for="fecha_nacimiento">Fecha nacimiento:</label>
        <input type="text" id="fecha_nacimiento" name="fecha_nacimiento" />
    </form>
</body>
<?php /**PATH C:\Users\Judith\Downloads\Xd\resources\views/editUsu/show.blade.php ENDPATH**/ ?>