<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <h2>Categorias</h2>
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('adminCategorias.store')); ?>">
                        <?php echo csrf_field(); ?>
                        <br>
                        <div class="form-group">
                            <label for="nombre">Nombre</label>
                            <input type="text" name="nombre" id="nombre" class="form-control" required>
                        </div><br>

                        <div class="form-group">
                            <label for="descripcion">Descripción</label>
                            <input type="text" name="descripcion" id="descripcion" class="form-control" required>
                        </div><br>

                        <button type="submit" class="btn btn-primary">Crear Categoria</button><br><br>

                        <a href="<?php echo e(route('adminCategorias.index')); ?>">Volver</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\Xd\resources\views/adminCategorias/create.blade.php ENDPATH**/ ?>