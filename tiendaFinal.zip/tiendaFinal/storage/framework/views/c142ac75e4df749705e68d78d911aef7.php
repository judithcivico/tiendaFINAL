<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro</title>
</head>
<body>
    <h1>Registro</h1>
   
        <label for="nick">Nick:</label>
        <input type="text" id="nick" name="nick" required>
        <br>

        <label for="email">Correo Electrónico:</label>
        <input type="email" id="email" name="email" required>
        <br>

        <label for="nombre">Nombre:</label>
        <input type="text" id="nombre" name="nombre" required>
        <br>

        <label for="apellido">Apellidos:</label>
        <input type="text" id="apellido" name="apellido" required>
        <br>

        <label for="dni">DNI:</label>
        <input type="text" id="dni" name="dni" required>
        <br>

        <label for="fechanasc">Fecha Nacimiento:</label>
        <input type="date" id="fechanasc" name="fechanasc" required>
        <br>

        <label for="contrasena">Contraseña:</label>
        <input type="password" id="contrasena" name="contrasena" required>
        <br>

        <label for="rol">Rol:</label>
        <select id="rol" name="rol" required>
            <option value="usuario">Usuario</option>
            <option value="administrador">Administrador</option>
        </select>
        <br>

        <button type="submit">Registrarse</button>
<a href="<?php echo e(route('login.index')); ?>">Cancelar</a>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Tienda\resources\views/login/register.blade.php ENDPATH**/ ?>